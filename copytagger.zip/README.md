# Clipboard-tagger
A firefox add-on that wraps the content of the tab copyboard between html tags or any custom string and also accumulates copies if accumulative copyboard is on.
