let accSelection = "";

document.addEventListener('copy', (event) => {
    console.log("WTF\n")
    const selection = document.getSelection();
    let tag = window.localStorage.getItem("tag");
    let acc = window.localStorage.getItem("acc-clipboard");
    let before = "";
    let after  = "";

    switch (tag) {
        case "<p>":
            before = "<p>"
            after = "</p>"
        break;
        case "<div>":
            before = "<div>"
            after = "</div>"
        break;
        case "<span>":
            before = "<span>"
            after = "</span>"
        break;
        case "<a>":
            before = "<a href='#'>"
            after = "</a>"
        break;
        case "<li>":
            before = "<li>"
            after = "</li>"
        break;
        case "<h1>":
            before = "<h1>"
            after = "</h1>"
        break;
        default:
            before = ""
            after = ""
            if (tag.includes("\\uwu/")) {
                before = tag.match(/(.*)\\uwu\/(.*)/)[1];
                after = tag.match(/(.*)\\uwu\/(.*)/)[2];
            }
    }

    if (acc === "false") {
        event.clipboardData.setData('text/plain', before + selection.toString() + after);
    } else if (acc === "true") {
        accSelection += before + selection.toString() + after + "\n";
        event.clipboardData.setData('text/plain', accSelection.toString());
    }
    event.preventDefault();
});
