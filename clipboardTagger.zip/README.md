# Clipboard-tagger
A firefox add-on that wraps the content of the tab copyboard between html tags or any custom string and also accumulates copies if accumulative copyboard is on.

# Instalation
Download the extension [here](https://addons.mozilla.org/firefox/downloads/file/3436971/clipboard_tagger-1.11-fx.xpi?src=devhub)

# How to use
## Default tags
1. Click on the Extension icon at your firefox tool-bar
2. Click in one of the tag buttons on the pop up
3. Close the pop up. Now all your copyboard copies should be wrapped in the tag of your choice
## Custom tags
1. Click on the Extension icon at your firefox tool-bar
2. Fill the before and after inputs with the strings you want to wrap your copied text with
3. Click the button custom under the input fields
## Accumulative copyboard
1. Click the checkbox for accumulative copyboard
2. Follow the steps above for default or custom tags
