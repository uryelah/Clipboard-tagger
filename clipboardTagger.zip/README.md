# Clipboard-tagger
A firefox add-on that wraps the content of the tab copyboard between html tags or any custom string and also accumulates copies if accumulative copyboard is on.

# Instalation
Download the extension [here](https://addons.mozilla.org/firefox/downloads/file/3436968/clipboard_tagger-1.1-fx.xpi?src=devhub)